<?php
require_once "../vendor/autoload.php";
$route = new \App\Route;

?>